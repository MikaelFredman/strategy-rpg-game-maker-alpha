STRATEGY RPG GAME MAKER - BETA PREVIEW 0.2.0-beta.10

This is a generic test build for Windows 10/11 and current Chrome or Microsoft Edge.
Ravenwood Pass is included as an editable example project. No private fan campaign is included.

INSTALL - STEP BY STEP
1. Download Strategy-RPG-Game-Maker-0.2.0-beta.10.zip.
2. Right-click the ZIP and choose Extract All. Do not run the program inside the ZIP.
3. Open the extracted folder.
4. Install Node.js 22.13 or newer from https://nodejs.org/ if it is not already installed.
5. Double-click Start Strategy RPG Game Maker Beta.cmd.
6. The first start installs the small local runtime and therefore needs Internet access once.
7. Wait for Chrome or Edge to open http://localhost:3000 and keep the launcher window open.
8. Later starts and ordinary editing work without Internet.

FIRST TEST
1. Ravenwood Pass should open automatically.
2. Open Help & Guide for the complete editor and gameplay instructions.
3. Open Validation Center before simulation; blocking errors must be fixed, while warnings explain optional improvements.
4. Open Project Dashboard to follow the complete Maps > Rules > Story > Content > Validate > Playtest workflow.
5. Start New Game for the ready-made balanced Good-versus-Evil example.
6. In tactical battle, level and race provide 1-5 AP. Level 1 starts at 1 AP; quick high-level races can reach 5 AP.
7. Map Browser offers editable outdoor, interior, cave and five tactical battle templates. Battle-map selectors show a miniature preview before you apply the map to selected world hexes.
8. Tactical attacks now show weapon-aware sword, spear, bow, staff and unarmed gestures. Game makers can author optional five-step pose chains and copy the base mesh pose or the previous step forward.
9. Tactical formations move one character at a time. Each character completes its route at the same 0.5-second-per-hex cadence before the next begins. AI rounds pause until arrows, fireballs, weapon gestures and damage labels have completed, and equipped bows/spears determine their correct attack range for every character.
10. Camera controls follow the standard editor pattern: left-drag pans, middle-drag orbits around the hex under the pointer and right-click opens Hex Actions.
11. Hex Actions includes Clear tile and reversible Hide/Show tile. Hidden tiles render completely black while preserving their authored data.
12. Tactical AI evaluates expected damage, target resistance, combat role and defence timing; useful health and mana potions consume real charges.
13. Strategic AI estimates travel and battle time against enemy reinforcement time. It exploits isolated weaker formations, consolidates when the window is unsafe and can combine full groups into a multi-group army.
14. Tactical Team Summary panels preserve each opening roster and maximum HP. Fallen characters remain listed at 0 HP with red row text, making casualties and the original team strength easy to compare.

DATA SAFETY
- The editor keeps rotating local project autosaves and an interrupted-game autosave.
- Use Save Project As and Save Game to create portable backup files.
- Keep important versions in another folder or backup location.
- Older supported projects are converted through versioned migrations; review Validation Center afterwards.

REPORTING
Downloads: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/releases
Bugs and improvements: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/issues/new/choose
Community: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/discussions

IMPORTANT
- This is a Beta Preview, not a finished AAA commercial release.
- Do not redistribute copyrighted projects, art, music, names or stories without permission.
- The commercial engine source and the owner's private fan campaign are not included.
