@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required.
  echo Download the current LTS release from https://nodejs.org/
  pause
  exit /b 1
)
for /f "tokens=1 delims=v." %%V in ('node --version') do set NODE_MAJOR=%%V
if %NODE_MAJOR% LSS 22 (
  echo Node.js 22.13 or newer is required. Installed: 
  node --version
  pause
  exit /b 1
)
if not exist "node_modules\vinext\package.json" (
  echo First-time setup: installing the local runtime...
  call npm install
  if errorlevel 1 (
    echo Runtime installation failed. Check the Internet connection and try again.
    pause
    exit /b 1
  )
)
echo Starting Strategy RPG Game Maker Beta Preview...
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "$deadline=(Get-Date).AddMinutes(3); while((Get-Date)-lt $deadline){ try { $response=Invoke-WebRequest -Uri 'http://localhost:3000' -UseBasicParsing -TimeoutSec 3; if($response.StatusCode -eq 200){ Start-Process 'http://localhost:3000'; break } } catch {}; Start-Sleep -Seconds 1 }"
call npm run start
endlocal
