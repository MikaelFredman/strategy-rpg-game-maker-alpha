STRATEGY RPG GAME MAKER - BETA PREVIEW 0.2.0-beta.14

This is a generic test build for Windows 10/11 and current Chrome or Microsoft Edge.
Ravenwood Pass is included as an editable example project. No private fan campaign is included.

INSTALL - STEP BY STEP
1. Download Strategy-RPG-Game-Maker-0.2.0-beta.14.zip.
2. Right-click the ZIP and choose Extract All. Do not run the program inside the ZIP.
3. Open the extracted folder.
4. Install Node.js 22.13 or newer from https://nodejs.org/ if it is not already installed.
5. Double-click Start Strategy RPG Game Maker Beta.cmd.
6. The first start installs the small local runtime and therefore needs Internet access once.
7. Wait for Chrome or Edge to open http://localhost:3000 and keep the launcher window open.
8. Later starts and ordinary editing work without Internet.

FIRST TEST
1. Ravenwood Pass should open automatically.
2. Open Help & Guide for the complete editor and gameplay instructions.
3. Open Validation Center before simulation; blocking errors must be fixed, while warnings explain optional improvements.
4. Open Project Dashboard to follow the complete Game Setup & Rules > Maps & Locations > Content Studio > Story, Quests & Dialogues > Validate > Playtest workflow.
5. Open Content Studio. Confirm that Characters & Creatures lists every placed formation, Items & Equipment opens the project item library and Visual Assets opens the articulated figure editor.
6. Start New Game for the ready-made balanced Good-versus-Evil example.
7. In tactical battle, level and race provide 1-5 AP. Level 1 starts at 1 AP; quick high-level races can reach 5 AP.
8. Map Browser offers editable outdoor, interior, cave and five tactical battle templates. Battle-map selectors show a miniature preview before you apply the map to selected world hexes.
9. Tactical attacks use the same weapon-aware, smoothly interpolated skeleton animations shown in Asset Studio for sword, spear, longbow, staff and unarmed actions. Pose chains may contain as many authored stages as the movement needs.
10. Longbows visibly raise, nock, draw to the face, release and reload. The bow string follows the draw hand and the loaded arrow becomes the authoritative flying projectile on release.
11. Tactical movement and combat resolve one character at a time. Each route uses the same 0.5-second-per-hex cadence; then initiative passes show one isolated action, animation and foreground sound before the next. Faster races and higher-level characters retain their additional AP without hiding other characters' first actions.
12. Camera controls follow the standard editor pattern: left-drag pans, middle-drag orbits around the hex under the pointer and right-click opens Hex Actions.
13. Hex Actions includes Clear tile and reversible Hide/Show tile. Hidden tiles render completely black while preserving their authored data.
14. Tactical AI evaluates expected damage, target resistance, combat role and defence timing; useful health and mana potions consume real charges.
15. Strategic AI estimates travel and battle time against enemy reinforcement time. It exploits isolated weaker formations, consolidates when the window is unsafe and can combine full groups into a multi-group army.
16. Tactical Team Summary panels preserve each opening roster and maximum HP. Fallen characters remain listed at 0 HP with red row text, making casualties and the original team strength easy to compare.
17. During each tactical action the acting character row and map tile are marked in gold. A character that loses health flashes red for approximately 0.25 seconds.

DATA SAFETY
- The editor keeps rotating local project autosaves and an interrupted-game autosave.
- Use Save Project As and Save Game to create portable backup files.
- Keep important versions in another folder or backup location.
- Older supported projects are converted through versioned migrations; review Validation Center afterwards.

REPORTING
Downloads: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/releases
Bugs and improvements: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/issues/new/choose
Community: https://github.com/MikaelFredman/strategy-rpg-game-maker-alpha/discussions

IMPORTANT
- This is a Beta Preview, not a finished AAA commercial release.
- Do not redistribute copyrighted projects, art, music, names or stories without permission.
- The commercial engine source and the owner's private fan campaign are not included.
